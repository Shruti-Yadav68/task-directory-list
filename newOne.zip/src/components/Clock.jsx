// // import React, { useState, useEffect } from 'react';
// // import axios from 'axios';

// // const Clock = ({ paused, selectedCountry }) => {
// //   const [currentTime, setCurrentTime] = useState('');

// //   useEffect(() => {
// //     const fetchTime = async () => {
// //       if (selectedCountry) {
// //         const response = await axios.get(`http://worldtimeapi.org/api/timezone/${selectedCountry}`);
// //         setCurrentTime(response.data.datetime.slice(11, 19));
// //       }
// //     };

// //     const interval = setInterval(() => {
// //       if (!paused) {
// //         fetchTime();
// //       }
// //     }, 1000);

// //     fetchTime();

// //     return () => clearInterval(interval);
// //   }, [paused, selectedCountry]);

// //   return <div>{currentTime}</div>;
// // };

// // export default Clock;

// import React, { useState, useEffect } from 'react';
// import axios from 'axios';

// const Clock = ({ paused, selectedCountry }) => {
//   const [currentTime, setCurrentTime] = useState('');
//   const [startTime, setStartTime] = useState(null);

//   useEffect(() => {
//     const fetchTime = async () => {
//       if (selectedCountry) {
//         const response = await axios.get(`http://worldtimeapi.org/api/timezone/${selectedCountry}`);
//         setCurrentTime(response.data.datetime.slice(11, 19));
//       }
//     };

//     if (!paused) {
//       if (!startTime) {
//         // Set the start time when transitioning from paused to unpaused
//         setStartTime(new Date());
//       }
//       fetchTime();
//     } else {
//       // Clear the start time when paused
//       setStartTime(null);
//     }

//     const interval = setInterval(() => {
//       if (!paused) {
//         fetchTime();
//       }
//     }, 1000);

//     return () => clearInterval(interval);
//   }, [paused, selectedCountry, startTime]);
  

//     return <div className='currentTime'>{currentTime}</div>;
//   };

//   export default Clock;


import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Clock = ({ selectedCountry, startTimeFrom }) => {
  const [currentTime, setCurrentTime] = useState('');
  const [paused, setPaused] = useState(false);
  const [startTime, setStartTime] = useState(null);

  useEffect(() => {
    const fetchTime = async () => {
      if (selectedCountry) {
        const response = await axios.get(`http://worldtimeapi.org/api/timezone/${selectedCountry}`);
        setCurrentTime(response.data.datetime.slice(11, 19));
      }
    };

    if (!paused) {
      if (!startTime) {
        // Set the start time to the given time or the current time
        setStartTime(startTimeFrom ? new Date().setHours(...startTimeFrom.split(':')) : new Date());
      }
      fetchTime();
    } else {
      // Clear the start time when paused
      setStartTime(null);
    }

    const interval = setInterval(() => {
      if (!paused) {
        fetchTime();
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [paused, selectedCountry, startTime, startTimeFrom]);

  const handlePauseClick = () => {
    setPaused(!paused);
  };

  return (
    <div>
      <div className='currentTime'>{currentTime}</div>
      <button onClick={handlePauseClick}>{paused ? 'Start' : 'Pause'}</button>
    </div>
  );
};

export default Clock;
